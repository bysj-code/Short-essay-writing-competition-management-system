﻿const base = {
    url : "http://localhost:8080/springbootr653y/"
}
export default base
