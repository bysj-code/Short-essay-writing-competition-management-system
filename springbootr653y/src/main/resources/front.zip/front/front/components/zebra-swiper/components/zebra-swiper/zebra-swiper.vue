<!-- uni_modules发布插件时，components中必须有一个和父级名称一致的组件，否则提示指定目录不存在，这样做的具体原因未知。故此文件为无用文件，仅做为上传插件时消除错误使用。 -->
<template>
</template>
<script>
</script>
<style>
</style>
